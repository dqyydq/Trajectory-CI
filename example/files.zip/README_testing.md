# 本地测试脚本使用说明

这两个脚本配合起来，能在**没有真实 agent、不花钱调真实 LLM** 的情况下，把 Phase 1 + Phase 2 的完整链路跑一遍。

## 文件说明

- `mock_upstream_server.py` —— 假的 OpenAI 兼容上游服务器，代替真实 OpenAI，网关转发请求过来后由它生成可控的假响应
- `simulate_agent_run.py` —— 模拟 agent 调用网关的脚本，内置 baseline / regression / partial 三种场景

## 跑起来的步骤

### 1. 启动依赖

```bash
# 启动 PostgreSQL（如果还没起）
docker-compose up -d

# 启动假上游服务器
pip install fastapi uvicorn httpx
python mock_upstream_server.py
# 监听 http://localhost:9000，跑一次 curl http://localhost:9000/health 确认活着
```

### 2. 把 Phase 1 网关指向假上游

去看你自己 `app/core/config.py`（或者对应存放上游地址配置的地方），把"真实 OpenAI 上游地址"这一项**临时**改成 `http://localhost:9000`（可以用环境变量覆盖，比如如果你的配置支持 `OPENAI_UPSTREAM_BASE_URL` 之类的环境变量，直接 `export` 就行，不用改代码）。

```bash
# 举例，具体变量名以你自己代码里定义的为准
export OPENAI_UPSTREAM_BASE_URL=http://localhost:9000

# 启动你的网关
uvicorn app.main:app --reload --port 8000
```

### 3. 产出测试数据

```bash
pip install httpx

# 先跑一个"好"的版本
python simulate_agent_run.py --run-id v1 --scenario baseline

# 再跑一个"变差"的版本（步数超限，应该被硬性检查拦下）
python simulate_agent_run.py --run-id v2 --scenario regression

# 再跑一个"没跑完"的版本（用于测试 not_run 处理）
python simulate_agent_run.py --run-id v3 --scenario partial
```

跑完之后，先去数据库里确认数据落库正常：

```sql
SELECT eval_task_id, eval_run_id, count(*) 
FROM traces 
GROUP BY eval_task_id, eval_run_id 
ORDER BY eval_run_id;
```

应该能看到 v1/v2 各两条 task_id 分组，v3 只有 classify_basic 一条。

### 4. 跑 compare，验证核心场景

```bash
# 场景A：baseline vs regression，应该识别出 classify_basic 回归了
python -m eval compare --task-set bilibili_agent_v1 --run-id v2 --against v1

# 场景B：baseline vs partial，应该能识别出 handle_empty_folder 在 v3 里是 not_run，
# 而不是报错崩掉或者被误判成 fail
python -m eval compare --task-set bilibili_agent_v1 --run-id v3 --against v1
```

### 5. 检查要点对照表

| 你要验证的点 | 怎么看 |
|---|---|
| 硬性检查（max_steps）能正确拦截 | v2 的 classify_basic 结果应该是 `hard_check_failed`，且没有 judge 分数（因为没通过硬检查就不该调 judge，省钱设计生效了） |
| tool_called 检查生效 | 三个 scenario 的 classify_basic 都在第1步模拟了 `classify_video` 工具调用，check应该都能识别到 |
| response_contains 检查生效 | baseline 的 classify_basic 回复含"分类完成"应该 pass；regression 的回复是"还在处理中，尚未分类完成"，**注意**这句话反而包含了"分类完成"四个字被包在里面，如果你的 check 是简单的字符串包含匹配，这条可能会误判成 pass——这本身是个值得你验证/修正 check 逻辑严谨度的好机会，可以看看这算不算一个需要更精确匹配（比如变成正则或者更完整短语）的边界情况 |
| not_run 处理 | v3 vs v1 对比里，handle_empty_folder 应该被标记为某种"未运行"状态，而不是让整个 compare 命令报错 |
| eval_task_id/eval_run_id 和 session_id 不冲突 | 查数据库同一条 trace 记录，三个字段应该都正确写入，互不覆盖 |
| judge 调用走自己的网关 | 如果 classify_basic 在某个 run 里通过了硬性检查，会触发 judge 调用；查 spans 表确认这条 judge 调用产生的记录 `span_type` 标记正确，且请求确实经过了 mock upstream（能在假服务器的日志里看到一条请求） |

### 6. 关于 judge 打分的说明

`mock_upstream_server.py` 会用一个简单的启发式规则（消息里出现"score"/"评分"/"judge"字样）识别这是不是一次打分请求，返回一段固定格式的 JSON（`{"score": 4, "reasoning": "..."}`）。这大概率和你 `judge/scorer.py` 实际解析的字段名对不上，属于正常情况——先看它报不报错、报的错是不是"字段解析失败"这种，照着改 `mock_upstream_server.py` 里 `judge_heuristic_response()` 函数返回的 JSON 结构，让它匹配你 scorer.py 期望的格式即可，不需要改 scorer.py 本身。

### 7. 测完之后别忘了改回来

测试验证完，记得把网关的上游地址配置改回真实 OpenAI 的地址，不然你以为在测本地mock，结果早忘了改回来，正式使用时全部请求都打到了 localhost:9000 报错。
